
import json
from pathlib import Path

import app as cine_app

from database import get_project, update_project
from engines.storyboard_engine import (
    create_storyboard_image,
    select_camera_motion,
)
from engines.visual_engine import (
    create_scene_clip,
    combine_scene_clips,
)
from engines.composition_engine import create_final_video
from engines.music_manager import get_music_for_style


PROJECT_ID = 9


def main():

    root = Path(cine_app.app.root_path)
    project = get_project(PROJECT_ID)

    if not project:
        raise RuntimeError(f"Project {PROJECT_ID} not found.")

    project_dir = root / "projects" / str(PROJECT_ID)

    # Reuse existing narration and subtitles.
    voice_rel = project.get("voice_path") or (
        f"projects/{PROJECT_ID}/narration.wav"
    )
    subtitle_rel = project.get("subtitle_path") or (
        f"projects/{PROJECT_ID}/subtitles.srt"
    )

    voice_file = root / voice_rel
    subtitle_file = root / subtitle_rel

    if not voice_file.is_file():
        raise FileNotFoundError(f"Narration missing: {voice_file}")

    if not subtitle_file.is_file():
        raise FileNotFoundError(f"Subtitles missing: {subtitle_file}")

    scenes = json.loads(project.get("scenes") or "[]")

    if not isinstance(scenes, list) or not scenes:
        raise RuntimeError("Project has no valid scenes.")

    # Calculate scene durations using existing narration.
    narration_duration = cine_app._audio_duration_seconds(
        voice_file
    )

    durations = cine_app._scene_durations(
        scenes,
        narration_duration
    )

    visuals_dir = project_dir / "scene_visuals"
    clips_dir = project_dir / "scene_clips"

    visuals_dir.mkdir(parents=True, exist_ok=True)
    clips_dir.mkdir(parents=True, exist_ok=True)

    clip_paths = []

    print("\n========== CINEFORGE AI PRODUCTION ==========")
    print(f"Project: {project['title']}")
    print(f"Scenes: {len(scenes)}")
    print(f"Narration: {narration_duration:.1f} seconds")
    print("Existing narration and subtitles will be preserved.")
    print("=============================================\n")

    # Generate new AI artwork and cinematic clips.
    for index, scene in enumerate(scenes):

        image_path = visuals_dir / f"scene_{index + 1:02d}.jpg"
        clip_path = clips_dir / f"scene_{index + 1:02d}.mp4"

        print(f"\n--- SCENE {index + 1}/{len(scenes)} ---")

        create_storyboard_image(
            scene,
            image_path,
            project["title"],
            index,
            len(scenes),
        )

        motion = select_camera_motion(scene, index)

        print(f"Camera movement: {motion}")
        print(f"Clip duration: {durations[index]} seconds")

        create_scene_clip(
            str(image_path),
            str(clip_path),
            duration=durations[index],
            motion=motion,
        )

        clip_paths.append(str(clip_path))

    # Combine all new scene clips.
    visual_rel = f"projects/{PROJECT_ID}/scene_video.mp4"
    visual_file = root / visual_rel

    print("\nCombining cinematic scenes...")

    combine_scene_clips(
        clip_paths,
        str(visual_file)
    )

    # Reuse existing music selection.
    try:
        music_file = get_music_for_style(
            project.get("genre", "ambient")
        )
    except FileNotFoundError:
        music_file = None

    # Render final video with existing audio and subtitles.
    final_rel = f"projects/{PROJECT_ID}/final_video.mp4"
    final_file = root / final_rel

    print("\nRendering final cinematic video...")

    create_final_video(
        str(visual_file),
        str(voice_file),
        str(subtitle_file),
        str(final_file),
        music_path=music_file,
    )

    update_project(
        PROJECT_ID,
        visual_video_path=visual_rel,
        final_video_path=final_rel,
        status="Video ready",
        error="",
    )

    print("\n=============================================")
    print("CINEFORGE AI PRODUCTION COMPLETED!")
    print(f"Final video: {final_file}")
    print("Narration and subtitles preserved.")
    print("=============================================")


if __name__ == "__main__":
    main()
