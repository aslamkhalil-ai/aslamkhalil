
import subprocess
from pathlib import Path

FFMPEG_PATH = (
    r"C:\Users\as\AppData\Local\Microsoft\WinGet\Packages"
    r"\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe"
    r"\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe"
)


def run_ffmpeg(command, timeout=600):
    """Execute FFmpeg and provide useful error details."""

    result = subprocess.run(
        command,
        capture_output=True,
        text=True,
        timeout=timeout
    )

    if result.returncode != 0:
        raise RuntimeError(
            result.stderr[-3000:] or "FFmpeg operation failed."
        )


def validate_output(path):
    """Ensure that the output file was successfully created."""

    if not path.exists() or path.stat().st_size == 0:
        raise RuntimeError(f"Output file was not created: {path}")


def create_scene_clip(
    image_path,
    output_path,
    duration=5,
    width=1280,
    height=720,
    fps=24,
    motion="zoom_in"
):
    """
    Create a cinematic video clip from a scene image.

    Supported camera movements:
    zoom_in, zoom_out, pan_left, pan_right,
    pan_up, pan_down, static
    """

    image_path = Path(image_path)
    output_path = Path(output_path)

    if not Path(FFMPEG_PATH).exists():
        raise FileNotFoundError(f"FFmpeg not found: {FFMPEG_PATH}")

    if not image_path.exists():
        raise FileNotFoundError(f"Scene image not found: {image_path}")

    if duration <= 0:
        raise ValueError("Duration must be greater than zero.")

    if width <= 0 or height <= 0 or fps <= 0:
        raise ValueError("Invalid video dimensions or FPS.")

    supported_motions = {
        "zoom_in",
        "zoom_out",
        "pan_left",
        "pan_right",
        "pan_up",
        "pan_down",
        "static"
    }

    if motion not in supported_motions:
        raise ValueError(f"Unsupported camera movement: {motion}")

    output_path.parent.mkdir(parents=True, exist_ok=True)

    total_frames = max(1, int(duration * fps))

    if motion == "zoom_in":
        zoom = "min(1.0+0.0005*on,1.12)"
        x = "iw/2-(iw/zoom/2)"
        y = "ih/2-(ih/zoom/2)"

    elif motion == "zoom_out":
        zoom = "max(1.0,1.12-0.0005*on)"
        x = "iw/2-(iw/zoom/2)"
        y = "ih/2-(ih/zoom/2)"

    elif motion == "pan_left":
        zoom = "1.10"
        x = f"(iw-iw/zoom)*on/{max(total_frames - 1, 1)}"
        y = "ih/2-(ih/zoom/2)"

    elif motion == "pan_right":
        zoom = "1.10"
        x = f"(iw-iw/zoom)*(1-on/{max(total_frames - 1, 1)})"
        y = "ih/2-(ih/zoom/2)"

    elif motion == "pan_up":
        zoom = "1.10"
        x = "iw/2-(iw/zoom/2)"
        y = f"(ih-ih/zoom)*on/{max(total_frames - 1, 1)}"

    elif motion == "pan_down":
        zoom = "1.10"
        x = "iw/2-(iw/zoom/2)"
        y = f"(ih-ih/zoom)*(1-on/{max(total_frames - 1, 1)})"

    else:
        zoom = "1.05"
        x = "iw/2-(iw/zoom/2)"
        y = "ih/2-(ih/zoom/2)"

    fade_duration = min(0.6, duration / 4)

    filter_complex = (
        f"scale={width * 2}:{height * 2}:"
        "force_original_aspect_ratio=increase,"
        f"crop={width * 2}:{height * 2},"
        f"zoompan=z='{zoom}':"
        f"x='{x}':"
        f"y='{y}':"
        f"d=1:s={width}x{height}:fps={fps},"
        f"fade=t=in:st=0:d={fade_duration},"
        f"fade=t=out:st={max(0, duration - fade_duration)}:"
        f"d={fade_duration},"
        "eq=contrast=1.06:saturation=1.12:brightness=0.01,"
        "unsharp=5:5:0.5:5:5:0.0,"
        "vignette=PI/5,"
        "format=yuv420p"
    )

    command = [
        FFMPEG_PATH,
        "-y",
        "-loop", "1",
        "-i", str(image_path),
        "-vf", filter_complex,
        "-frames:v", str(total_frames),
        "-an",
        "-c:v", "libx264",
        "-preset", "ultrafast",
        "-crf", "20",
        "-pix_fmt", "yuv420p",
        "-movflags", "+faststart",
        str(output_path)
    ]

    run_ffmpeg(command, timeout=300)
    validate_output(output_path)

    return str(output_path)


def combine_scene_clips(clip_paths, output_path):
    """Combine multiple rendered scene clips into one MP4 video."""

    if not clip_paths:
        raise ValueError("No scene clips provided.")

    clips = [Path(path).resolve() for path in clip_paths]

    for clip in clips:
        if not clip.exists():
            raise FileNotFoundError(f"Scene clip not found: {clip}")

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    list_file = output_path.parent / "scene_list.txt"

    try:
        with open(list_file, "w", encoding="utf-8") as file:
            for clip in clips:
                safe_path = str(clip).replace("\\", "/")
                safe_path = safe_path.replace("'", "'\\''")
                file.write(f"file '{safe_path}'\n")

        command = [
            FFMPEG_PATH,
            "-y",
            "-f", "concat",
            "-safe", "0",
            "-i", str(list_file),
            "-c", "copy",
            "-movflags", "+faststart",
            str(output_path)
        ]

        run_ffmpeg(command)
        validate_output(output_path)

        return str(output_path)

    finally:
        if list_file.exists():
            list_file.unlink()


def add_background_music(
    video_path,
    music_path,
    output_path,
    music_volume=0.18
):
    """Add background music while preserving original narration."""

    video_path = Path(video_path)
    music_path = Path(music_path)
    output_path = Path(output_path)

    if not video_path.exists():
        raise FileNotFoundError(f"Video not found: {video_path}")

    if not music_path.exists():
        raise FileNotFoundError(f"Music not found: {music_path}")

    if not 0 <= music_volume <= 1:
        raise ValueError("Music volume must be between 0 and 1.")

    output_path.parent.mkdir(parents=True, exist_ok=True)

    command = [
        FFMPEG_PATH,
        "-y",
        "-i", str(video_path),
        "-stream_loop", "-1",
        "-i", str(music_path),
        "-filter_complex",
        (
            f"[1:a]volume={music_volume}[bg];"
            "[0:a][bg]amix=inputs=2:"
            "duration=first:dropout_transition=2[a]"
        ),
        "-map", "0:v:0",
        "-map", "[a]",
        "-c:v", "copy",
        "-c:a", "aac",
        "-b:a", "192k",
        "-shortest",
        "-movflags", "+faststart",
        str(output_path)
    ]

    run_ffmpeg(command)
    validate_output(output_path)

    return str(output_path)


def render_final_video(
    video_path,
    voice_path,
    music_path,
    output_path,
    music_volume=0.18
):
    """Combine scene video, narration and background music."""

    video_path = Path(video_path)
    voice_path = Path(voice_path)
    music_path = Path(music_path)
    output_path = Path(output_path)

    for path in [video_path, voice_path, music_path]:
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")

    if not 0 <= music_volume <= 1:
        raise ValueError("Music volume must be between 0 and 1.")

    output_path.parent.mkdir(parents=True, exist_ok=True)

    command = [
        FFMPEG_PATH,
        "-y",
        "-i", str(video_path),
        "-i", str(voice_path),
        "-stream_loop", "-1",
        "-i", str(music_path),
        "-filter_complex",
        (
            "[1:a]volume=1.0[voice];"
            f"[2:a]volume={music_volume}[music];"
            "[voice][music]amix=inputs=2:"
            "duration=first:dropout_transition=2[audio]"
        ),
        "-map", "0:v:0",
        "-map", "[audio]",
        "-c:v", "copy",
        "-c:a", "aac",
        "-b:a", "192k",
        "-shortest",
        "-movflags", "+faststart",
        str(output_path)
    ]

    run_ffmpeg(command)
    validate_output(output_path)

    return str(output_path)
