
import subprocess
from pathlib import Path

from engines.visual_engine import FFMPEG_PATH


def create_final_video(
    video_path,
    narration_path,
    subtitle_path,
    output_path,
    music_path=None
):
    """Combine video, narration, optional music and subtitles."""

    video = Path(video_path).resolve()
    narration = Path(narration_path).resolve()
    subtitles = Path(subtitle_path).resolve()
    output = Path(output_path).resolve()

    for file_path, label in [
        (video, "Video"),
        (narration, "Narration"),
        (subtitles, "Subtitle")
    ]:
        if not file_path.is_file():
            raise FileNotFoundError(
                f"{label} file not found: {file_path}"
            )

    music = None

    if music_path:
        music = Path(music_path).resolve()

        if not music.is_file():
            raise FileNotFoundError(
                f"Music file not found: {music}"
            )

    output.parent.mkdir(parents=True, exist_ok=True)

    subtitle_filter_path = (
        str(subtitles)
        .replace("\\", "/")
        .replace(":", r"\:")
        .replace("'", r"\'")
    )

    command = [
        FFMPEG_PATH,
        "-y",
        "-i", str(video),
        "-i", str(narration)
    ]

    if music:
        command.extend([
            "-stream_loop", "-1",
            "-i", str(music)
        ])
        subtitle_style = (
    "FontName=Arial,"
    "FontSize=11,"
    "Bold=0,"
    "PrimaryColour=&H00FFFFFF,"
    "OutlineColour=&H00000000,"
    "BorderStyle=1,"
    "Outline=1,"
    "Shadow=0,"
    "Alignment=2,"
    "MarginL=140,"
    "MarginR=140,"
    "MarginV=35,"
    "WrapStyle=2"
)

    command.extend([
        "-vf",
        f"subtitles='{subtitle_filter_path}':"
        f"force_style='{subtitle_style}'",

        "-map", "0:v:0",
        "-c:v", "libx264",
        "-preset", "ultrafast",
        "-pix_fmt", "yuv420p",
    ])

    if music:
        command.extend([
            "-filter_complex",
            "[1:a]volume=1.0[voice];"
            "[2:a]volume=0.15[music];"
            "[voice][music]amix=inputs=2:"
            "duration=first:dropout_transition=2[audio]",
            "-map", "[audio]"
        ])
    else:
        command.extend([
            "-map", "1:a:0"
        ])

    command.extend([
        "-c:a", "aac",
        "-b:a", "128k",
        "-shortest",
        "-movflags", "+faststart",
        str(output)
    ])

    result = subprocess.run(
        command,
        capture_output=True,
        text=True,
        timeout=600
    )

    if result.returncode != 0:
        raise RuntimeError(
            result.stderr[-3000:]
            or "Final video rendering failed."
        )

    if not output.exists() or output.stat().st_size == 0:
        raise RuntimeError("Final video was not created.")

    return str(output)
