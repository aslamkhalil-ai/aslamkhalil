
from pathlib import Path
from faster_whisper import WhisperModel


# Lightweight CPU configuration for CineForge AI
MODEL_SIZE = "base"
DEVICE = "cpu"
COMPUTE_TYPE = "int8"


def generate_subtitles(audio_path, output_path, language="en"):
    """
    Generate synchronized SRT subtitles directly from narration audio.
    Uses actual speech timestamps instead of estimated word timing.
    """

    audio_path = Path(audio_path)
    output_path = Path(output_path)

    if not audio_path.exists():
        raise FileNotFoundError(f"Audio file not found: {audio_path}")

    output_path.parent.mkdir(parents=True, exist_ok=True)

    print("Loading Whisper model...")

    model = WhisperModel(
        MODEL_SIZE,
        device=DEVICE,
        compute_type=COMPUTE_TYPE
    )

    print("Analyzing narration audio...")

    segments, info = model.transcribe(
        str(audio_path),
        language=language,
        beam_size=1,
        vad_filter=True,
        word_timestamps=False
    )

    def format_timestamp(seconds):
        milliseconds = int(round(seconds * 1000))

        hours = milliseconds // 3600000
        milliseconds %= 3600000

        minutes = milliseconds // 60000
        milliseconds %= 60000

        secs = milliseconds // 1000
        milliseconds %= 1000

        return (
            f"{hours:02}:{minutes:02}:{secs:02},"
            f"{milliseconds:03}"
        )

    srt_blocks = []

    for index, segment in enumerate(segments, start=1):
        text = segment.text.strip()

        if not text:
            continue

        start_time = max(0, segment.start)
        end_time = max(start_time, segment.end)

        srt_blocks.append(
            f"{len(srt_blocks) + 1}\n"
            f"{format_timestamp(start_time)} --> "
            f"{format_timestamp(end_time)}\n"
            f"{text}\n"
        )

    if not srt_blocks:
        raise RuntimeError("Whisper could not detect any speech.")

    output_path.write_text(
        "\n".join(srt_blocks),
        encoding="utf-8"
    )

    print(f"Detected language: {info.language}")
    print(f"Subtitle segments: {len(srt_blocks)}")

    return str(output_path)
