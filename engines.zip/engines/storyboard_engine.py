
"""CineForge AI - Local AI Cinematic Storyboard Engine.

Uses locally downloaded Stable Diffusion 1.5.
Generates scene-specific cinematic images without paid APIs.
"""

from pathlib import Path
import gc
import random

import torch
from PIL import (
    Image,
    ImageEnhance,
    ImageFilter,
    ImageOps,
)
from diffusers import StableDiffusionPipeline


WIDTH = 1280
HEIGHT = 720
MODEL_PATH = Path("models/stable-diffusion-v1-5")

# Stable Diffusion settings for CPU-only systems
IMAGE_SIZE = 512
INFERENCE_STEPS = 20
GUIDANCE_SCALE = 7.5

_pipeline = None


# ---------------------------------------------------------
# LOCAL AI MODEL
# ---------------------------------------------------------

def _load_pipeline():
    """Load Stable Diffusion once and reuse it for all scenes."""

    global _pipeline

    if _pipeline is not None:
        return _pipeline

    if not MODEL_PATH.exists():
        raise FileNotFoundError(
            f"Stable Diffusion model not found: {MODEL_PATH.resolve()}"
        )

    torch.set_num_threads(2)

    print("\n[CineForge] Loading local Stable Diffusion model...")

    _pipeline = StableDiffusionPipeline.from_pretrained(
        str(MODEL_PATH),
        torch_dtype=torch.float32,
        use_safetensors=True,
        local_files_only=True,
        safety_checker=None,
        feature_extractor=None,
    )

    _pipeline = _pipeline.to("cpu")
    _pipeline.enable_attention_slicing()

    print("[CineForge] Stable Diffusion ready.")

    return _pipeline


# ---------------------------------------------------------
# SCENE CLASSIFICATION
# ---------------------------------------------------------

def _classify_scene(description):

    text = str(description).lower()

    categories = {
        "space": (
            "astronaut", "spaceship", "space station",
            "galaxy", "planet", "orbit", "cosmic",
            "spacesuit", "alien"
        ),
        "horror": (
            "horror", "ghost", "haunted", "darkness",
            "monster", "abandoned", "creature",
            "shadow", "graveyard", "terrifying"
        ),
        "city": (
            "city", "street", "building", "urban",
            "skyscraper", "traffic", "neon", "downtown"
        ),
        "forest": (
            "forest", "jungle", "woods", "trees",
            "mountain", "river", "wilderness", "nature"
        ),
        "historical": (
            "castle", "kingdom", "medieval", "ancient",
            "warrior", "historical", "empire",
            "temple", "palace", "battle"
        ),
        "technology": (
            "hologram", "computer", "control room",
            "robot", "technology", "laboratory",
            "machine", "digital", "interface"
        ),
    }

    for category, keywords in categories.items():
        if any(word in text for word in keywords):
            return category

    return "cinematic"


# ---------------------------------------------------------
# CAMERA MOVEMENT
# ---------------------------------------------------------

def select_camera_motion(scene, scene_index=0):
    """Choose a repeatable camera movement."""

    if isinstance(scene, dict):
        description = (
            scene.get("visual_description")
            or scene.get("visual_prompt")
            or ""
        )
    else:
        description = str(scene or "")

    category = _classify_scene(description)

    movements = {
        "space": ["zoom_in", "pan_left", "pan_right", "zoom_out"],
        "horror": ["zoom_in", "pan_left", "zoom_in", "static"],
        "city": ["pan_left", "pan_right", "zoom_in"],
        "forest": ["zoom_in", "pan_up", "pan_right"],
        "historical": ["zoom_out", "pan_left", "zoom_in"],
        "technology": ["zoom_in", "pan_right", "static"],
        "cinematic": ["zoom_in", "zoom_out", "pan_left", "pan_right"],
    }

    options = movements[category]

    return options[scene_index % len(options)]


# ---------------------------------------------------------
# CINEMATIC PROMPT ENGINE
# ---------------------------------------------------------

def _build_prompt(scene, project_title, category):

    if isinstance(scene, dict):

        description = (
            scene.get("visual_prompt")
            or scene.get("visual_description")
            or scene.get("description")
            or "A mysterious cinematic scene"
        )

        action = scene.get("action", "")
        setting = scene.get("setting", "")
        mood = scene.get("mood", "")

    else:
        description = str(scene or "A cinematic scene")
        action = ""
        setting = ""
        mood = ""

    description = str(description)[:650]

    details = " ".join(
        str(item) for item in [action, setting, mood]
        if item
    )

    style = {
        "space": (
            "realistic science fiction film cinematography, "
            "astronauts in detailed spacesuits, enormous planets, "
            "realistic spacecraft, cosmic atmosphere"
        ),
        "horror": (
            "photorealistic horror movie cinematography, "
            "ominous shadows, unsettling atmosphere, "
            "abandoned environments, dramatic low-key lighting"
        ),
        "city": (
            "photorealistic cinematic urban environment, "
            "detailed architecture, atmospheric lighting, "
            "realistic streets and buildings"
        ),
        "forest": (
            "photorealistic wilderness cinematography, "
            "dense natural environments, atmospheric fog, "
            "dramatic sunlight and realistic landscapes"
        ),
        "historical": (
            "historically inspired epic movie cinematography, "
            "detailed ancient architecture, realistic costumes, "
            "cinematic natural lighting"
        ),
        "technology": (
            "photorealistic futuristic science fiction environment, "
            "advanced machinery, realistic technology, "
            "cinematic lighting and detailed materials"
        ),
        "cinematic": (
            "photorealistic Hollywood movie cinematography, "
            "dramatic environment, realistic materials, "
            "professional film lighting"
        ),
    }

    prompt = f"""
    A single breathtaking cinematic movie frame.

    Film concept: {project_title}

    Scene description: {description}

    Additional scene details: {details}

    Visual style: {style[category]}.

    Wide cinematic composition, professional production design,
    realistic physical environments, detailed textures,
    dramatic lighting, atmospheric depth, natural shadows,
    realistic color grading, volumetric light,
    carefully composed foreground and background,
    professional cinematography, high visual quality.

    The image must visually depict the actual scene.
    No text, no captions, no logos, no watermarks.
    """

    return prompt.strip()


NEGATIVE_PROMPT = """
blurry, low resolution, pixelated, low quality,
cartoon, anime, illustration, painting,
text, letters, subtitles, watermark, logo,
deformed human, malformed hands, extra fingers,
duplicate people, duplicate objects,
distorted face, unrealistic anatomy,
bad proportions, oversaturated colors,
flat lighting, artificial plastic textures
"""


# ---------------------------------------------------------
# IMAGE PROCESSING
# ---------------------------------------------------------

def _prepare_cinematic_frame(image, output_path):
    """Convert generated artwork into a cinematic 16:9 frame."""

    image = image.convert("RGB")

    # Fill 16:9 canvas without stretching the generated artwork.
    image = ImageOps.fit(
        image,
        (WIDTH, HEIGHT),
        method=Image.Resampling.LANCZOS,
        centering=(0.5, 0.48),
    )

    # Improve contrast and color slightly.
    image = ImageEnhance.Contrast(image).enhance(1.12)
    image = ImageEnhance.Color(image).enhance(1.08)
    image = ImageEnhance.Sharpness(image).enhance(1.18)

    # Cinematic dark gradient behind subtitles.
    overlay = Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 0))
    pixels = overlay.load()

    gradient_start = 520

    for y in range(gradient_start, HEIGHT):
        progress = (y - gradient_start) / (HEIGHT - gradient_start)
        alpha = int(175 * (progress ** 1.4))

        for x in range(WIDTH):
            pixels[x, y] = (0, 0, 0, alpha)

    image = Image.alpha_composite(
        image.convert("RGBA"),
        overlay
    ).convert("RGB")

    # Very subtle finishing.
    image = image.filter(ImageFilter.UnsharpMask(
        radius=1.2,
        percent=65,
        threshold=4
    ))

    image.save(
        output_path,
        format="JPEG",
        quality=95,
        optimize=True
    )

    return str(output_path)


# ---------------------------------------------------------
# MAIN STORYBOARD FUNCTION
# ---------------------------------------------------------

def create_storyboard_image(
    scene,
    output_path,
    project_title,
    scene_index,
    total_scenes
):
    """Generate one actual AI-created cinematic scene."""

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if isinstance(scene, dict):
        scene_number = int(
            scene.get("scene_number", scene_index + 1)
        )
        description = (
            scene.get("visual_description")
            or scene.get("visual_prompt")
            or scene.get("description")
            or "A cinematic scene"
        )
        genre = str(scene.get("genre", "")).lower()
    else:
        scene_number = scene_index + 1
        description = str(scene or "A cinematic scene")
        genre = ""

    category = _classify_scene(
        f"{genre} {description}"
    )

    prompt = _build_prompt(
        scene,
        project_title,
        category
    )

    # Repeatable seed for consistent project generation.
    seed = scene_number * 7919 + sum(
        ord(char) for char in str(project_title)
    )

    generator = torch.Generator(device="cpu").manual_seed(seed)

    print(
        f"\n[CineForge] Generating AI scene "
        f"{scene_index + 1}/{total_scenes}: {category}"
    )
    print("[CineForge] This may take several minutes on CPU.")

    pipe = _load_pipeline()

    with torch.inference_mode():

        result = pipe(
            prompt=prompt,
            negative_prompt=NEGATIVE_PROMPT,
            height=IMAGE_SIZE,
            width=IMAGE_SIZE,
            num_inference_steps=INFERENCE_STEPS,
            guidance_scale=GUIDANCE_SCALE,
            generator=generator,
        )

    generated_image = result.images[0]

    saved_path = _prepare_cinematic_frame(
        generated_image,
        output_path
    )

    del result
    del generated_image
    gc.collect()

    print(f"[CineForge] AI scene saved: {saved_path}")

    return saved_path
