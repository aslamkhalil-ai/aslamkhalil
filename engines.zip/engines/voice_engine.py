
import os
import subprocess
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent.parent

VOICE_MODEL = BASE_DIR / "en_US-lessac-medium.onnx"
VOICE_CONFIG = BASE_DIR / "en_US-lessac-medium.onnx.json"


def generate_voice(text, output_path):
    """Generate local narration using Piper TTS."""

    if not text or not text.strip():
        raise ValueError("Narration text is empty.")

    if not VOICE_MODEL.exists():
        raise FileNotFoundError(
            f"Piper voice model not found: {VOICE_MODEL}"
        )

    if not VOICE_CONFIG.exists():
        raise FileNotFoundError(
            f"Piper voice configuration not found: {VOICE_CONFIG}"
        )

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    command = [
        "piper",
        "--model", str(VOICE_MODEL),
        "--config", str(VOICE_CONFIG),
        "--output_file", str(output_path)
    ]

    result = subprocess.run(
        command,
        input=text,
        text=True,
        capture_output=True,
        timeout=300
    )

    if result.returncode != 0:
        raise RuntimeError(
            result.stderr or "Piper voice generation failed."
        )

    if not output_path.exists() or output_path.stat().st_size == 0:
        raise RuntimeError("Voice file was not generated.")

    return str(output_path)
