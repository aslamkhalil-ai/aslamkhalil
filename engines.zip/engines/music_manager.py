
import random
from pathlib import Path


# Project music directory
BASE_DIR = Path(__file__).resolve().parent.parent
MUSIC_DIR = BASE_DIR / "assets" / "music"


# Music categories
MUSIC_CATEGORIES = {
    "cinematic": "cinematic",
    "horror": "horror",
    "documentary": "documentary",
    "ambient": "ambient",
    "educational": "ambient",
    "promotional": "cinematic",
    "suspense": "horror",
    "thriller": "horror",
    "mystery": "ambient",
    "science fiction": "cinematic",
    "sci-fi": "cinematic"
}


def get_music_for_style(style):
    """
    Select a random background music file
    according to the video style.
    """

    category = MUSIC_CATEGORIES.get(
        style.lower().strip(),
        "ambient"
    )

    category_folder = MUSIC_DIR / category

    if not category_folder.exists():
        raise FileNotFoundError(
            f"Music folder not found: {category_folder}"
        )

    music_files = list(category_folder.glob("*.mp3"))

    if not music_files:
        raise FileNotFoundError(
            f"No MP3 music files found in {category_folder}"
        )

    selected_music = random.choice(music_files)

    print(f"Music category: {category}")
    print(f"Selected music: {selected_music.name}")

    return str(selected_music)


if __name__ == "__main__":

    music = get_music_for_style("cinematic")

    print("\nMusic selection successful!")
    print(music)
