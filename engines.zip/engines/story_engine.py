
import os
import json
import requests


def generate_story(idea: str, genre: str, duration: int):
    base = os.getenv(
        "OLLAMA_BASE_URL",
        "http://localhost:11434"
    ).rstrip("/")

    model = os.getenv(
        "OLLAMA_MODEL",
        "llama3.2:latest"
    )

    # Keep the scene count manageable for low-resource laptops.
    scene_count = {
        30: 3,
        45: 4,
        60: 5,
        90: 6
    }.get(duration, max(3, min(6, duration // 12)))

    prompt = f"""
You are a professional cinematic short-video scriptwriter.

Create a high-quality {genre} video production plan.

CREATIVE IDEA:
{idea}

TARGET DURATION:
Exactly approximately {duration} seconds.

SCENE COUNT:
Create exactly {scene_count} scenes.

Return ONLY valid JSON using this structure:

{{
  "title": "Short cinematic title",
  "logline": "One compelling sentence",
  "script": "Complete natural narration for the video",
  "scenes": [
    {{
      "scene_number": 1,
      "duration_seconds": 12,
      "visual_description": "Detailed cinematic scene description",
      "camera_direction": "Camera movement and framing",
      "narration": "Narration for this scene",
      "sound_design": "Background ambience and sound effects",
      "visual_prompt": "Detailed visual generation prompt"
    }}
  ]
}}

IMPORTANT RULES:
- Create exactly {scene_count} scenes.
- Scene durations must add up to {duration} seconds.
- Keep narration engaging and suitable for the target duration.
- Every scene must have a distinct visual environment.
- Use cinematic lighting, atmosphere and composition.
- Camera directions must vary between scenes.
- Make the ending memorable and engaging.
- Keep each description concise but visually specific.
- Do not include markdown or explanations outside JSON.
"""

    try:
        response = requests.post(
            base + "/api/generate",
            json={
                "model": model,
                "prompt": prompt,
                "stream": False,
                "format": "json",
                "keep_alive": "5m",
                "options": {
                    "temperature": 0.6,
                    "num_ctx": 2048,
                    "num_predict": 1400
                }
            },
            timeout=(10, 600)
        )

        response.raise_for_status()

        result = response.json()
        raw = result.get("response", "").strip()

        if not raw:
            raise ValueError("Ollama returned an empty response.")

        data = json.loads(raw)

        script = data.get("script", "").strip()
        scenes = data.get("scenes", [])

        if not script or not isinstance(scenes, list) or not scenes:
            raise ValueError(
                "The local model returned an incomplete story plan."
            )

        if len(scenes) != scene_count:
            raise ValueError(
                f"Expected {scene_count} scenes, "
                f"but received {len(scenes)}."
            )

        required_fields = [
            "scene_number",
            "duration_seconds",
            "visual_description",
            "camera_direction",
            "narration",
            "sound_design",
            "visual_prompt"
        ]

        for index, scene in enumerate(scenes, start=1):
            if not isinstance(scene, dict):
                raise ValueError(f"Scene {index} is invalid.")

            for field in required_fields:
                if field not in scene or not scene[field]:
                    raise ValueError(
                        f"Scene {index} is missing: {field}"
                    )

        total_scene_duration = sum(
            int(scene["duration_seconds"])
            for scene in scenes
        )

        if total_scene_duration != duration:
            raise ValueError(
                f"Scene durations total {total_scene_duration}s "
                f"instead of {duration}s. Please retry."
            )

        return {
            "script": script,
            "scenes": json.dumps(
                scenes,
                indent=2,
                ensure_ascii=False
            )
        }

    except requests.exceptions.Timeout as error:
        raise RuntimeError(
            "Ollama took too long to generate the story. "
            "Try again after checking system resources."
        ) from error

    except requests.exceptions.ConnectionError as error:
        raise RuntimeError(
            "Cannot connect to Ollama. Make sure Ollama is running."
        ) from error

    except json.JSONDecodeError as error:
        raise RuntimeError(
            "Ollama returned invalid JSON. Please try again."
        ) from error
